import CreateVehicleCategoryComp from "@/src/app/(public)/vehicle/category/createVehicleCategory/CreateVehicleCategoryComp";
export default function CreateVehicleCategoryPage() {
  return (
    <>
      <CreateVehicleCategoryComp />
    </>
  );
}
