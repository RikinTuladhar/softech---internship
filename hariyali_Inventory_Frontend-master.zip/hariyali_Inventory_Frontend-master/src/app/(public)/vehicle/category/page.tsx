import React from "react";
import VehicleCategoryIndexComp from "@/src/app/(public)/vehicle/category/VehicleCategoryIndexComp";
function VehicleCategory() {
  return (
    <div>
      <VehicleCategoryIndexComp />
    </div>
  );
}

export default VehicleCategory;
