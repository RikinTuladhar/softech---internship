import React from "react";
import VehicleIndexPage from "@/src/app/(public)/vehicle/vehicle/VehicleIndexPage";
function Vehicle() {
  return (
    <div>
      <VehicleIndexPage />
    </div>
  );
}

export default Vehicle;
