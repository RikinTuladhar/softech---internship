import CreateVehicleComp from "@/src/app/(public)/vehicle/vehicle/createVehicle/CreateVehicleComp";

export default function CreateVehiclePage() {
  return (
    <>
      <CreateVehicleComp />
    </>
  );
}
