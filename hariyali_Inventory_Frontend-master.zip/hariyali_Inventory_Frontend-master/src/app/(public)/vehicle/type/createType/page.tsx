import CreateVehicleTypeComp from "@/src/app/(public)/vehicle/type/createType/CreateVehicleTypeComp";
export default function CreateTypePage() {
  return (
    <>
      <CreateVehicleTypeComp />
    </>
  );
}
