import CreateVehicleUseComp from "@/src/app/(public)/vehicle/use/createVehicleUse/CreateVehicleUseComp";

export default function CreateVehicleUsePage() {
  return <CreateVehicleUseComp />;
}
