import React from "react";
import VehicleUseComp from "@/src/app/(public)/vehicle/use/VehicleUseComp";
function VehicleUse() {
  return (
    <div>
      <VehicleUseComp />
    </div>
  );
}

export default VehicleUse;
