import React from "react";
import CreateCompany from "./CreateCompany";
function CreateComp() {
  return (
    <div>
      <CreateCompany />
    </div>
  );
}

export default CreateComp;
