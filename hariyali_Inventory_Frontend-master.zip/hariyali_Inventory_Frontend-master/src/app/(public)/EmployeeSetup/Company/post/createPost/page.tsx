import React from 'react'
import CreatePostComp from './CreatePostComp'
function CreatePost() {
  return (
    <div>
      <CreatePostComp/>
    </div>
  )
}

export default CreatePost