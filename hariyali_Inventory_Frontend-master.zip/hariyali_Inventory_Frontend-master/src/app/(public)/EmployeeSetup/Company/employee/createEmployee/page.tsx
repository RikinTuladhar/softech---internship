import React from "react";
import CreateEmployeeComp from "./CreateEmployeeComp";
function CreateEmployee() {
  return (
    <div>
      <CreateEmployeeComp />
    </div>
  );
}

export default CreateEmployee;
