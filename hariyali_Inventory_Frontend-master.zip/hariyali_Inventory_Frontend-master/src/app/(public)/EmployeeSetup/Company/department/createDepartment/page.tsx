import React from "react";
import CreateDepartmentComp from "./CreateDepartmentComp";
function CreateDepartment() {
  return (
    <div>
      <CreateDepartmentComp />
    </div>
  );
}

export default CreateDepartment;
