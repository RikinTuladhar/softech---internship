import AddMerchantForm from "@/src/app/(public)/dashboard/entrepreneur/AddEntrepreneurForm/AddBusinessManagerComp";

export default function BusinessManagerCreate() {
  return (
    <>
      <AddMerchantForm />
    </>
  );
}
