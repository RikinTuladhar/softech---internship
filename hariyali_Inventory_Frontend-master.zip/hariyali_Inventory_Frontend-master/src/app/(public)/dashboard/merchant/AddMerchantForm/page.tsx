import AddProjectComp from "@/src/app/(public)/dashboard/merchant/AddMerchantForm/AddProjectComp";

const AddProjectIndex = () => {
  return (
    <>
      <AddProjectComp />
    </>
  );
};
export default AddProjectIndex;
