
import React from "react";
import AddFarmerForm from "./AddFarmerForm";

const AddFarmersForm = () => {
  
  return (
    <>
    <AddFarmerForm/>
      </>
  );
};

export default AddFarmersForm;
