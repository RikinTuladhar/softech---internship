"use client";
import React from "react";
import AddFarmerGroup from "./AddFarmerGroup";
const AddFarmersGroupIndex=() => {
  return(<>
  <AddFarmerGroup/>
  </>)
};

export default AddFarmersGroupIndex;
