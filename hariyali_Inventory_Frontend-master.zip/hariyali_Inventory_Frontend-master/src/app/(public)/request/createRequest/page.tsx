import React from 'react'
import AddRequestForm from './AddRequestForm'
function CreateRequestIndex() {
  return (
    <div>
        <AddRequestForm/>
    </div>
  )
}

export default CreateRequestIndex