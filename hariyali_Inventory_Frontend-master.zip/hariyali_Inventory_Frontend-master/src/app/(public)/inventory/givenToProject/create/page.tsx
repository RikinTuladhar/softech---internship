import React from 'react'
import GivenToProjectComp from './GiveToProjectComp'
function GivenToProject() {
  return (
    <div>
      <GivenToProjectComp/>
    </div>
  )
}

export default GivenToProject