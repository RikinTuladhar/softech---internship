import React from 'react'
import GivenToGroupComp from './GiveToGroupComp'
export default function GivenToGroupIndex() {
  return (
    <div>
      <GivenToGroupComp/>
    </div>
  )
}
