import React from "react";
import GiveToFarmerComp from "./GiveToFarmerComp";
export default function GiveToFarmer() {
  return (
    <div>
      <GiveToFarmerComp />
    </div>
  );
}
