import React from "react";
import UnderConstruction from "@/src/components/reusable/UnderConstruction";
export default function TakenFromFarmerIndex() {
  return (
    <div>
      <UnderConstruction />
    </div>
  );
}
