import React from "react";
import CreateBank from "./CreateBank";

export default function IndexCreateBank() {
  return (
    <div>
      <CreateBank />
    </div>
  );
}
