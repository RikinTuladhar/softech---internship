import React from "react";
import BankIndex from "./BankIndex";

export default function BankIndexPage() {
  return (
    <div>
      <BankIndex />
    </div>
  );
}
