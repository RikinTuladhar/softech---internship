import CreateFiscalYear from "./CreateFiscalYear";

const CreateFiscal = () => {
  return <CreateFiscalYear />;
};
export default CreateFiscal;
