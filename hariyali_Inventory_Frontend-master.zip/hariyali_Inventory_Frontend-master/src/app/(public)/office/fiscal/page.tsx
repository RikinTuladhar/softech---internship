import React from "react";
import FiscalYearIndex from "./FiscalYearIndex";

export default function FiscalYearIndexPage() {
  return (
    <div>
      <FiscalYearIndex />
    </div>
  );
}
