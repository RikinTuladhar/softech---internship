import React from 'react'
import CreateMaterialComp from './CreateMaterialComp'
export default function CreateMatrial() {

   return(
    <>
    <CreateMaterialComp  />
    </>
   )
}
