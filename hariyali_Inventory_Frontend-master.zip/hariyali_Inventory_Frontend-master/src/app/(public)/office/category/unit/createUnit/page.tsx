import React from "react";
import CreateUnits from "./CreateUnit";

export default function CreateUnitPage() {
  return (
    <div>
      <CreateUnits />
    </div>
  );
}
