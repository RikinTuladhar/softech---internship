import React from "react";
import UnitIndex from "./UnitIndex";

export default function Unit() {
  return (
    <div>
      <UnitIndex />
    </div>
  );
}
