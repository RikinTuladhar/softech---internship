import React from 'react'
import CreateItemComp from './CreateItemPage'
export default function ItemCreateIndex() {
  return (
    <>
    <CreateItemComp/>
    </>
  )
}
