import React from "react";
import CreateSubCategoryComp from "./createSubCategory";

function CreateSubCategoryPage() {
  return (
    <div>
      <CreateSubCategoryComp />
    </div>
  );
}

export default CreateSubCategoryPage;
