import React from "react";
import SubCategoryIndex from "./SubCategoryIndex";

function SubCategory() {
  return (
    <div>
      <SubCategoryIndex />
    </div>
  );
}

export default SubCategory;
