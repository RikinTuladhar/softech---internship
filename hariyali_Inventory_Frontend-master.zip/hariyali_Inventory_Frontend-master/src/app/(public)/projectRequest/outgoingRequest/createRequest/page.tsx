import React from 'react'
import CreateRequestByProjectComp from './CreateProjectRequest'
export default function CreateRequestByProjectIndex() {
  return (
    <div>
        <CreateRequestByProjectComp/>
    </div>
  )
}
