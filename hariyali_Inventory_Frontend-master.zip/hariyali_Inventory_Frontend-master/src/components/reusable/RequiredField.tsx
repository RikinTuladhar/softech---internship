export default function RequiredField() {
  return <span className={"text-red-600"}>*</span>;
}
